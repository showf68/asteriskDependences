const char* HYLAFAX_VERSION_STRING =	"HylaFAX (tm) Version 7.0.5";
