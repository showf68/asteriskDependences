/* SoundPluginFAKE header file
 */

#include <SoundPlugin/SoundPlugin.h>

