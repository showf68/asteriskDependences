/* Unicode and threads functions aliases, to share the file
 * between all OS
 *
 * Note: only the functions which are always unicode are found here
 */
