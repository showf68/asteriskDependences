/*
 * Float return example in PureBasic
 */

#include "Simple.h"


M_PBFUNCTION(float) PB_FloatReturn()
{
  return 15.21;
}
