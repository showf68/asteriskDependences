/*
 *  ListIconGadget() command for PureBasic
 */

#include <Gadget/Gadget.h>

// Define the unicode functions
#define PB_ListIconSampleGadget M_UnicodeFunction(PB_ListIconSampleGadget)
#define PB_ListIconSampleGadget2 M_UnicodeFunction(PB_ListIconSampleGadget2)

